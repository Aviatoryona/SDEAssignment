﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDEAssignment
{
    // This project can output the Class library as a NuGet Package.
    // To enable this option, right-click on the project and select the Properties menu item. In the Build tab select "Produce outputs on build".
    public class Employees
    {
        private DirectedSparseGraph<Employee> graph;
        private Dictionary<string, Employee> allEmployees;


        public Employees(string[] lines)
        {
            graph = new DirectedSparseGraph<Employee>();
            allEmployees = new Dictionary<string, Employee>();
            var lns = lines.Select(a => a.Split('\t'));
            var myCsv = from line in lns
                      select (from piece in line
                              select piece);
            int ceos = 0;
            foreach (var n in myCsv)
            {

                var p = n.GetEnumerator();
                while (p.MoveNext())
                {
                    try
                    {
                        var data = p.Current.Split(',');
                        if (string.IsNullOrEmpty(data[0]))
                        {
                            Console.WriteLine("Inavlid, Employee cannot have empty Id");
                            continue;
                        }

                        if (string.IsNullOrEmpty(data[1]) && ceos < 1)
                        {
                            ceos++;
                        }
                        else if (string.IsNullOrEmpty(data[1]) && ceos == 1)
                        {
                            Console.WriteLine("Number CEOs, exceed 1");
                            continue;
                        }


                        int sal = 0;
                        // ensure that employee salary is a valid integer
                        if (Int32.TryParse(data[2], out sal))
                        {
                            var empl = new Employee(data[0], data[1], sal);
                            try
                            {
                                allEmployees.Add(empl.Id, empl);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Error pushing data to employee dic", e);
                            }

                            if (!graph.HasVertex(empl))
                            {
                                graph.AddVertex(empl);
                            }

                        }
                        else
                        {
                            Console.WriteLine("Invalid Salary value, integer expected");
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                p.Dispose();

            }

            foreach (KeyValuePair<string, Employee> kvp in allEmployees)
            {
                if (!string.IsNullOrEmpty(kvp.Value.Manager))
                {
                    bool doubleLinked = false;
                    foreach (Employee employee in graph.DepthFirstWalk(kvp.Value).ToArray())
                    {
                        if (employee.Equals(kvp.Value.Manager))
                        {
                            doubleLinked = true;
                            break;
                        }
                    }

                    if (graph.IncomingEdges(kvp.Value).ToArray().Length < 1 && !doubleLinked)
                    {
                        graph.AddEdge(allEmployees[kvp.Value.Manager], kvp.Value);
                    }
                    else
                    {
                        Console.WriteLine();
                    }
                }

            }

        }

        public long getSalary(string managerId)
        {
            var salaryBudget = 0;
            try
            {
                var employeesInPath = graph.DepthFirstWalk(allEmployees[managerId]).GetEnumerator();
                while (employeesInPath.MoveNext())
                {
                    salaryBudget += employeesInPath.Current.Salary;

                }
            }
            catch (Exception var0)
            {
                Console.WriteLine("Error", var0);
            }

            return salaryBudget;
        }
    }

    public class Employee : IComparable<Employee>
    {
        //getter n setters
        public string Id { get; set; }
        public int Salary { get; set; }

        public string Manager { get; set; }

        //constructor
        public Employee(string id, string manager, int salary)
        {
            Id = id;
            Salary = salary;
            Manager = manager;
        }

        public int CompareTo(Employee other)
        {
            if (other == null) return -1;
            return string.Compare(this.Id, other.Id,
                StringComparison.OrdinalIgnoreCase);
        }
    }
}
