﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace EmployeeTest
{
    [TestClass]
    public class UnitTest1
    {
        public void EmployeesTest()
        {
            var lines = File.ReadAllLines("../../../csv1.csv");
            Employees employees = new Employees(lines);
            Assert.Equal(1800, employees.SalaryBudget("Employee1"));
            Assert.Equal(200, employees.SalaryBudget("Employee2"));

        }
        

        //is salary valid?
        public void Test3()
        {
            var lines = File.ReadAllLines("../../../csv3.csv");
            Employees employees = new Employees(lines);
            Assert.Equal(1800, employees.SalaryBudget("Employee1"));
            Assert.Equal(0, employees.SalaryBudget("Employee2"));
            Assert.Equal(1300, employees.SalaryBudget("Employee3"));
            Assert.Equal(600, employees.SalaryBudget("Employee6"));
        }
    }
}
